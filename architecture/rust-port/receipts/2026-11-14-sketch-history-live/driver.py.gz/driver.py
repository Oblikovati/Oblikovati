import ctypes
from ctypes.util import find_library
from pathlib import Path
import re
import subprocess
import time
import json
import base64
import urllib.request

artifacts = Path('/tmp/oblikovati-r3-foreground')
artifacts.mkdir(exist_ok=True)
(artifacts / 'cube.opd').unlink(missing_ok=True)
x11 = ctypes.CDLL(find_library('X11'))
xtest = ctypes.CDLL(find_library('Xtst'))
x11.XOpenDisplay.restype = ctypes.c_void_p
x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
x11.XStringToKeysym.restype = ctypes.c_ulong
x11.XStringToKeysym.argtypes = [ctypes.c_char_p]
x11.XKeysymToKeycode.restype = ctypes.c_ubyte
x11.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
x11.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
x11.XSetInputFocus.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
xtest.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
xtest.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
xtest.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
display = x11.XOpenDisplay(None)
assert display, 'expected isolated X11 display'
window_offset = (0, 0)
session_id = None

def rpc(message: dict) -> dict:
    global session_id
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
    if session_id:
        headers['Mcp-Session-Id'] = session_id
    request = urllib.request.Request('http://127.0.0.1:17800/mcp', json.dumps(message).encode(), headers)
    with urllib.request.urlopen(request, timeout=20) as response:
        session_id = response.headers.get('Mcp-Session-Id', session_id)
        body = response.read().decode()
    if not body:
        return {}
    if body.startswith('event:'):
        body = next(line[6:] for line in body.splitlines() if line.startswith('data: '))
    return json.loads(body)

def inspect_sketch(stage: str) -> None:
    reply = rpc({'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'get_sketch', 'arguments': {'sketchIndex': 0}}})
    (artifacts / f'{stage}-sketch.json').write_text(json.dumps(reply, indent=2))
    print(stage, json.dumps(reply), flush=True)
    assert not reply.get('error'), f'{stage}: expected a successful host query: {reply}'
    result = reply['result']
    assert not result.get('isError'), f'{stage}: expected a successful sketch query: {result}'
    observed = json.loads(result['content'][0]['text'])
    assert observed['dof'] == 0 and observed['healthy'], f'{stage}: expected healthy DOF=0 sketch: {observed}'

def settle() -> None:
    x11.XSync(display, 0)
    time.sleep(.12)

def move(x: int, y: int) -> None:
    assert xtest.XTestFakeMotionEvent(display, -1, x + window_offset[0], y + window_offset[1], 0)
    settle()

def click(x: int, y: int) -> None:
    move(x, y)
    for pressed in [1, 0]:
        assert xtest.XTestFakeButtonEvent(display, 1, pressed, 0)
        settle()

def key(name: str) -> None:
    code = x11.XKeysymToKeycode(display, x11.XStringToKeysym(name.encode()))
    assert code, f'key {name!r}: expected X11 keycode'
    for pressed in [1, 0]:
        assert xtest.XTestFakeKeyEvent(display, code, pressed, 0)
        settle()

def text(value: str) -> None:
    for char in value:
        key({' ': 'space', '/': 'slash', '.': 'period', '-': 'minus'}.get(char, char))

def capture(window: int, name: str) -> None:
    settle()
    path = artifacts / f'{name}.png'
    reply = rpc({'jsonrpc': '2.0', 'id': 4, 'method': 'tools/call', 'params': {'name': 'capture_window', 'arguments': {'path': str(path)}}})
    assert not reply.get('error') and not reply['result'].get('isError'), f'{name}: expected a completed MCP capture: {reply}'
    images = [item for item in reply['result']['content'] if item['type'] == 'image']
    assert len(images) == 1 and images[0]['mimeType'] == 'image/png'
    returned_png = base64.b64decode(images[0]['data'], validate=True)
    assert path.read_bytes() == returned_png, f'{name}: expected the exact completed PNG returned by MCP'
    print(f'{name}: MCP returned {len(returned_png)} PNG bytes', flush=True)
    if name in ['rectangle-10mm', 'rectangle-20mm', 'undo-10mm', 'redo-settled-20mm']:
        inspect_sketch(name)

binary = '/home/vmiguel/git/oblikovati-workspace/oblikovati-rust/target/debug/oblikovati'
with (artifacts / 'application.log').open('w') as log:
    app = subprocess.Popen([binary], stdout=log, stderr=subprocess.STDOUT)
    try:
        window = None
        started = time.monotonic()
        while time.monotonic() - started < 20:
            assert app.poll() is None, 'expected live desktop process'
            inventory = subprocess.run(['xwininfo', '-root', '-tree'], capture_output=True, text=True, check=True).stdout
            match = re.search(r'(0x[0-9a-f]+) "Oblikovati', inventory)
            if match:
                window = int(match.group(1), 16)
                break
            time.sleep(.1)
        assert window is not None, 'expected visible Oblikovati window'
        geometry = subprocess.run(['xwininfo', '-id', hex(window)], text=True, capture_output=True, check=True).stdout
        (artifacts / 'window-geometry.txt').write_text(geometry)
        window_offset = tuple(int(re.search(r'Absolute upper-left ' + axis + r':\s*(-?\d+)', geometry).group(1)) for axis in ['X', 'Y'])
        x11.XSetInputFocus(display, window, 1, 0)
        settle()
        import socket
        for _ in range(200):
            try:
                with socket.create_connection(('127.0.0.1', 17800), timeout=.1):
                    break
            except OSError:
                assert app.poll() is None, 'desktop stopped before MCP startup'
                time.sleep(.1)
        else:
            raise RuntimeError('MCP listener did not start in 20 seconds')
        rpc({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-03-26', 'capabilities': {}, 'clientInfo': {'name': 'oblikovati-ui-acceptance', 'version': '1'}}})
        rpc({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        click(40, 68)
        capture(window, 'new-dialog')
        click(430, 286)
        click(155, 671)
        capture(window, 'part-created')
        click(70, 80)
        click(900, 294)
        capture(window, 'sketch-editing')
        click(1370, 80)
        capture(window, 'sketch-finished')
        def chord(name):
            control = x11.XKeysymToKeycode(display, x11.XStringToKeysym(b'Control_L'))
            assert xtest.XTestFakeKeyEvent(display, control, 1, 0)
            settle()
            key(name)
            assert xtest.XTestFakeKeyEvent(display, control, 0, 0)
            settle()
        def sketch(stage, expected):
            reply = rpc({'jsonrpc': '2.0', 'id': 7, 'method': 'tools/call', 'params': {'name': 'get_sketch', 'arguments': {'sketchIndex': 0}}})
            (artifacts / f'{stage}.json').write_text(json.dumps(reply, indent=2))
            assert not reply.get('error'), reply
            if expected is None:
                assert reply['result'].get('isError'), reply
            else:
                assert not reply['result'].get('isError'), reply
                observed = json.loads(reply['result']['content'][0]['text'])
                assert observed['editing'] == expected and observed['plane'] == 'XY', observed
            print(stage, 'editing', expected, flush=True)
        chord('z')
        capture(window, 'undo-finish')
        sketch('undo-finish', True)
        chord('z')
        capture(window, 'undo-create')
        sketch('undo-create', None)
        chord('y')
        capture(window, 'redo-create')
        sketch('redo-create', True)
        chord('y')
        capture(window, 'redo-finish')
        sketch('redo-finish', False)
        print('Sketch history input journey passed', flush=True)
    finally:
        if app.poll() is None:
            app.terminate()
        app.wait(timeout=20)
        x11.XCloseDisplay(display)
