// SPDX-License-Identifier: GPL-2.0-only
use super::*;
use oblikovati_api::types::{SKETCH_PREFERENCE_SATISFIED, SKETCH_PREFERENCE_UNAVAILABLE};

fn independent_pair() -> Sketch2D {
    let mut geometry = Sketch2D::default();
    geometry.add_point(entity(1), [0.0, 0.0]).unwrap();
    geometry.add_point(entity(2), [8.0, 4.0]).unwrap();
    geometry
}

#[test]
fn typed_constraint_preference_keeps_the_first_point_and_reports_status() {
    let (mut files, document, mut guids) = fresh_geometry(DOCUMENT_PART, independent_pair());
    let mut input = request("coincident", &[1, 2]);
    input.preferred_point = Some(std::boxed::Box::new(1));
    let result = add(&mut files, &mut guids, &input).unwrap();
    assert_eq!(result.preference_status, SKETCH_PREFERENCE_SATISFIED);
    assert_eq!(result.dof, 2);
    let sketch = &files
        .workspace()
        .session(document)
        .unwrap()
        .snapshot()
        .sketches
        .sketches()[0];
    for id in [entity(1), entity(2)] {
        assert!(
            sketch
                .geometry()
                .point(id)
                .unwrap()
                .position
                .iter()
                .all(|value| value.abs() < 1e-7)
        );
    }
}

#[test]
fn unrelated_preferred_point_is_rejected_before_a_history_step() {
    let (mut files, document, mut guids) = fresh(DOCUMENT_PART);
    let before = files.workspace().session(document).unwrap().generation();
    let mut input = request("coincident", &[1, 2]);
    input.preferred_point = Some(std::boxed::Box::new(4));
    assert!(add(&mut files, &mut guids, &input).is_err());
    assert_eq!(
        files.workspace().session(document).unwrap().generation(),
        before
    );
}

#[test]
fn fixed_second_point_reports_unavailable_and_creates_the_relation() {
    let (mut files, document, mut guids) = fresh_geometry(DOCUMENT_PART, independent_pair());
    add(&mut files, &mut guids, &request("fix", &[2])).unwrap();
    let mut input = request("coincident", &[1, 2]);
    input.preferred_point = Some(std::boxed::Box::new(1));
    let result = add(&mut files, &mut guids, &input).unwrap();
    assert_eq!(result.preference_status, SKETCH_PREFERENCE_UNAVAILABLE);
    let sketch = &files
        .workspace()
        .session(document)
        .unwrap()
        .snapshot()
        .sketches
        .sketches()[0];
    assert_eq!(
        sketch.geometry().point(entity(1)).unwrap().position,
        [8.0, 4.0]
    );
    assert_eq!(sketch.geometry().geometric_constraints().count(), 2);
}

#[test]
fn a_line_cannot_be_used_as_a_preferred_point() {
    let (mut files, document, mut guids) = fresh(DOCUMENT_PART);
    let before = files.workspace().session(document).unwrap().generation();
    let mut input = request("horizontal", &[7]);
    input.preferred_point = Some(std::boxed::Box::new(7));
    assert!(add(&mut files, &mut guids, &input).is_err());
    assert_eq!(
        files.workspace().session(document).unwrap().generation(),
        before
    );
}
