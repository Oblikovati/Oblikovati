@sketch @viewport @mouse @inherits_common_sketch_viewport
Feature: Pick sketch entities in Measure

  Background:
    Given the MCAD Software is displaying an editable sketch
    And the viewport pointer is idle

  @needs_fixture
  Scenario: Distinguish an arc midpoint pick from a curve pick
    Given an arc with a selectable midpoint is available in Measure
    When the user selects the arc midpoint
    Then the selection is identified as a Middle Point
    When the user clears the selection and selects the arc near its start
    Then the selection is identified as a Curve

  @needs_fixture @capture_only
  Scenario: Measure a selected sketch line as a curve
    Given the capture sketch contains one line and Measure is open
    When the user selects the line in the viewport
    Then Measure reports Selection 1 as Curve
    And Measure reports the line length as 13.854 millimeters
