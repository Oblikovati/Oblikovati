@solid_model @viewport @mouse
Feature: Create and modify solid features through viewport interactions

  Background:
    Given the MCAD Software is displaying a part in the solid modeling workspace
    And the viewport pointer is idle

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Pick requested model geometry for a feature tool
    Given a valid solid model is open and a feature tool has a viewport selection field active
    When the user clicks an eligible model entity requested by that field
    Then the field identifies the selected entity and its type
    And the viewport displays a distinct selected state

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Preview a feature after its required viewport selections
    Given a solid feature tool is requesting model geometry
    And its required eligible model entities are available in the viewport
    When the user picks the required entities
    Then the feature preview reflects the selected geometry and current parameters
    And the tool's confirmation state reflects whether its required inputs are complete

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Commit a created feature to the model browser
    Given a solid feature tool displays a valid preview after viewport selection
    When the user confirms the feature
    Then the preview is committed to the model
    And a feature entry appears in the model browser

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Modify an existing feature and accept the updated preview
    Given the part contains an editable solid feature
    When the user opens the feature for modification
    Then its current selection and parameters are displayed
    When the user changes a parameter or requested viewport selection
    Then the preview reflects the pending modification
    When the user confirms the modification
    Then the existing feature is updated in the model browser
    And the updated result appears in the viewport

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Cancel a feature modification without changing the committed model
    Given an existing solid feature is open for modification with a changed preview
    When the user cancels the modification
    Then the edit panel closes
    And the previously committed model remains visible


