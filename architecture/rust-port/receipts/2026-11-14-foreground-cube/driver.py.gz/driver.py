import ctypes
from ctypes.util import find_library
from pathlib import Path
import re
import subprocess
import time
import json
import base64
import urllib.request

artifacts = Path('/tmp/oblikovati-r3-foreground')
artifacts.mkdir(exist_ok=True)
(artifacts / 'cube.opd').unlink(missing_ok=True)
x11 = ctypes.CDLL(find_library('X11'))
xtest = ctypes.CDLL(find_library('Xtst'))
x11.XOpenDisplay.restype = ctypes.c_void_p
x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
x11.XStringToKeysym.restype = ctypes.c_ulong
x11.XStringToKeysym.argtypes = [ctypes.c_char_p]
x11.XKeysymToKeycode.restype = ctypes.c_ubyte
x11.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
x11.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
x11.XSetInputFocus.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
xtest.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
xtest.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
xtest.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
display = x11.XOpenDisplay(None)
assert display, 'expected isolated X11 display'
window_offset = (0, 0)
session_id = None

def rpc(message: dict) -> dict:
    global session_id
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
    if session_id:
        headers['Mcp-Session-Id'] = session_id
    request = urllib.request.Request('http://127.0.0.1:17800/mcp', json.dumps(message).encode(), headers)
    with urllib.request.urlopen(request, timeout=20) as response:
        session_id = response.headers.get('Mcp-Session-Id', session_id)
        body = response.read().decode()
    if not body:
        return {}
    if body.startswith('event:'):
        body = next(line[6:] for line in body.splitlines() if line.startswith('data: '))
    return json.loads(body)

def inspect_sketch(stage: str) -> None:
    reply = rpc({'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'get_sketch', 'arguments': {'sketchIndex': 0}}})
    (artifacts / f'{stage}-sketch.json').write_text(json.dumps(reply, indent=2))
    print(stage, json.dumps(reply), flush=True)
    assert not reply.get('error'), f'{stage}: expected a successful host query: {reply}'
    result = reply['result']
    assert not result.get('isError'), f'{stage}: expected a successful sketch query: {result}'
    observed = json.loads(result['content'][0]['text'])
    assert observed['dof'] == 0 and observed['healthy'], f'{stage}: expected healthy DOF=0 sketch: {observed}'

def settle() -> None:
    x11.XSync(display, 0)
    time.sleep(.12)

def move(x: int, y: int) -> None:
    assert xtest.XTestFakeMotionEvent(display, -1, x + window_offset[0], y + window_offset[1], 0)
    settle()

def click(x: int, y: int) -> None:
    move(x, y)
    for pressed in [1, 0]:
        assert xtest.XTestFakeButtonEvent(display, 1, pressed, 0)
        settle()

def key(name: str) -> None:
    code = x11.XKeysymToKeycode(display, x11.XStringToKeysym(name.encode()))
    assert code, f'key {name!r}: expected X11 keycode'
    for pressed in [1, 0]:
        assert xtest.XTestFakeKeyEvent(display, code, pressed, 0)
        settle()

def text(value: str) -> None:
    for char in value:
        key({' ': 'space', '/': 'slash', '.': 'period', '-': 'minus'}.get(char, char))

def capture(window: int, name: str) -> None:
    settle()
    path = artifacts / f'{name}.png'
    reply = rpc({'jsonrpc': '2.0', 'id': 4, 'method': 'tools/call', 'params': {'name': 'capture_window', 'arguments': {'path': str(path)}}})
    assert not reply.get('error') and not reply['result'].get('isError'), f'{name}: expected a completed MCP capture: {reply}'
    images = [item for item in reply['result']['content'] if item['type'] == 'image']
    assert len(images) == 1 and images[0]['mimeType'] == 'image/png'
    returned_png = base64.b64decode(images[0]['data'], validate=True)
    assert path.read_bytes() == returned_png, f'{name}: expected the exact completed PNG returned by MCP'
    print(f'{name}: MCP returned {len(returned_png)} PNG bytes', flush=True)
    if name in ['rectangle-10mm', 'rectangle-20mm', 'undo-10mm', 'redo-settled-20mm']:
        inspect_sketch(name)

binary = '/home/vmiguel/git/oblikovati-workspace/oblikovati-rust/target/debug/oblikovati'
with (artifacts / 'application.log').open('w') as log:
    app = subprocess.Popen([binary], stdout=log, stderr=subprocess.STDOUT)
    try:
        window = None
        started = time.monotonic()
        while time.monotonic() - started < 20:
            assert app.poll() is None, 'expected live desktop process'
            inventory = subprocess.run(['xwininfo', '-root', '-tree'], capture_output=True, text=True, check=True).stdout
            match = re.search(r'(0x[0-9a-f]+) "Oblikovati', inventory)
            if match:
                window = int(match.group(1), 16)
                break
            time.sleep(.1)
        assert window is not None, 'expected visible Oblikovati window'
        geometry = subprocess.run(['xwininfo', '-id', hex(window)], text=True, capture_output=True, check=True).stdout
        (artifacts / 'window-geometry.txt').write_text(geometry)
        window_offset = tuple(int(re.search(r'Absolute upper-left ' + axis + r':\s*(-?\d+)', geometry).group(1)) for axis in ['X', 'Y'])
        x11.XSetInputFocus(display, window, 1, 0)
        settle()
        import socket
        for _ in range(200):
            try:
                with socket.create_connection(('127.0.0.1', 17800), timeout=.1):
                    break
            except OSError:
                assert app.poll() is None, 'desktop stopped before MCP startup'
                time.sleep(.1)
        else:
            raise RuntimeError('MCP listener did not start in 20 seconds')
        rpc({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-03-26', 'capabilities': {}, 'clientInfo': {'name': 'oblikovati-ui-acceptance', 'version': '1'}}})
        rpc({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        click(40, 68)
        capture(window, 'new-dialog')
        click(430, 286)
        click(155, 671)
        capture(window, 'part-created')
        click(846, 43)
        capture(window, 'parameters-open')
        click(420, 227)
        text('size')
        click(420, 250)
        text('10 mm')
        click(343, 272)
        capture(window, 'parameter-added')
        click(440, 272)
        click(70, 80)
        capture(window, 'plane-selection')
        click(900, 294)
        capture(window, 'sketch-open')
        click(70, 80)
        click(720, 449)
        move(1000, 600)
        text('size')
        key('Tab')
        text('size')
        key('Return')
        capture(window, 'rectangle-10mm')
        key('Escape')
        click(1370, 80)
        capture(window, 'sketch-finished')
        click(183, 71)
        capture(window, 'extrude-dialog')
        click(700, 362)
        text('size')
        click(675, 386)
        capture(window, 'extrude-preview')
        click(735, 386)
        click(1321, 216)
        capture(window, 'cube-10mm')
        for tool in ['body_list', 'body_physical_properties', 'get_reference_keys']:
            reply = rpc({'jsonrpc': '2.0', 'id': 5, 'method': 'tools/call', 'params': {'name': tool, 'arguments': ({'bodyIndex': 0} if tool == 'body_physical_properties' else {})}})
            (artifacts / f'{tool}.json').write_text(json.dumps(reply, indent=2))
            print(tool, json.dumps(reply), flush=True)
            assert not reply.get('error') and not reply['result'].get('isError'), f'{tool}: {reply}'
        measured = json.loads(json.loads((artifacts / 'body_physical_properties.json').read_text())['result']['content'][0]['text'])
        assert abs(measured['volumeMm3'] - 1000) < 1e-6
        assert abs(measured['surfaceAreaMm2'] - 600) < 1e-6
        topology = json.loads(json.loads((artifacts / 'get_reference_keys.json').read_text())['result']['content'][0]['text'])
        saved_face = topology['bodies'][0]['faces'][0]['key']
        click(845, 43)
        click(345, 318)
        click(420, 250)
        for _ in range(5): key('BackSpace')
        text('20 mm')
        click(385, 272)
        click(440, 272)
        for stage, target, button in [('edited', 8000., None), ('undo', 1000., (157, 43)), ('redo', 8000., (202, 43))]:
            if button: click(*button)
            capture(window, stage)
            reply = rpc({'jsonrpc': '2.0', 'id': 6, 'method': 'tools/call', 'params': {'name': 'body_physical_properties', 'arguments': {'bodyIndex': 0}}})
            assert not reply.get('error') and not reply['result'].get('isError'), reply
            observed = json.loads(reply['result']['content'][0]['text'])
            print(stage, 'volume', observed['volumeMm3'], flush=True)
            assert abs(observed['volumeMm3'] - target) < 1e-5, observed
        click(115, 43)
        capture(window, 'save-dialog')
        text('/tmp/oblikovati-r3-foreground/cube.opd')
        key('Return')
        assert (artifacts / 'cube.opd').is_file(), 'expected document saved through the UI'
        capture(window, 'saved')
        click(24, 10)
        capture(window, 'file-menu')
        click(29, 101)
        click(24, 10)
        click(30, 50)
        capture(window, 'open-dialog')
        text('/tmp/oblikovati-r3-foreground/cube.opd')
        key('Return')
        click(1321, 216)
        capture(window, 'reopened')
        reply = rpc({'jsonrpc': '2.0', 'id': 7, 'method': 'tools/call', 'params': {'name': 'body_physical_properties', 'arguments': {'bodyIndex': 0}}})
        assert not reply.get('error') and not reply['result'].get('isError'), reply
        measured = json.loads(reply['result']['content'][0]['text'])
        assert abs(measured['volumeMm3'] - 8000) < 1e-5, measured
        reply = rpc({'jsonrpc': '2.0', 'id': 8, 'method': 'tools/call', 'params': {'name': 'get_reference_keys', 'arguments': {}}})
        assert not reply.get('error') and not reply['result'].get('isError'), reply
        reopened = json.loads(reply['result']['content'][0]['text'])
        assert saved_face in [face['key'] for face in reopened['bodies'][0]['faces']], 'expected same named face after reopen'
        reply = rpc({'jsonrpc': '2.0', 'id': 9, 'method': 'tools/call', 'params': {'name': 'assign_appearance', 'arguments': {'scope': 'face', 'key': saved_face, 'appearanceId': 'default'}}})
        (artifacts / 'reopened-face-resolve.json').write_text(json.dumps(reply, indent=2))
        print('reopened face assignment', json.dumps(reply), flush=True)
        assert not reply.get('error') and not reply['result'].get('isError'), reply
        print('Reopened cube and resolved saved face', flush=True)
    finally:
        if app.poll() is None:
            app.terminate()
        app.wait(timeout=20)
        x11.XCloseDisplay(display)
