Feature: Body properties dialog
  The MCAD Software presents body properties and can calculate physical values on request.

  @needs_fixture
  Scenario: Update unavailable physical properties for a solid body
    Given a part containing one visible solid body is active in the MCAD Software
    And the body's physical properties are unavailable in the current session
    When the user right-clicks the body in the model browser
    And the user chooses Properties
    Then the Body Properties dialog opens with the body name
    And mass, area, volume, and the X, Y, and Z coordinates of the center of gravity show N/A
    And the dialog displays a body appearance selector and OK and Cancel buttons
    When the user chooses Update
    Then mass, area, volume, and the center of gravity coordinates display calculated values
    And the solid remains highlighted behind the dialog
    When the user chooses Cancel
    Then the dialog closes
    And the solid remains visible
    When the user reopens Body Properties for the same body in the same session
    Then the calculated physical properties remain displayed
    When the user chooses Cancel
    Then the dialog closes

  @needs_fixture
  Scenario: Cancel a body appearance selection
    Given a part with a visible solid body is active in the MCAD Software
    And the body appearance is set to As Part
    When the user opens Body Properties for the body from the model browser
    And the user opens the Body Appearance list
    Then a scrollable list of named appearances is displayed
    When the user chooses Black
    Then Body Appearance displays Black
    When the user chooses Cancel
    And the user reopens Body Properties for the same body
    Then Body Appearance displays As Part
    And the solid remains visible
    When the user chooses Cancel
    Then the dialog closes

  @needs_fixture
  Scenario: Apply and restore a body appearance
    Given a part with a visible solid body is active in the MCAD Software
    And the body appearance is set to As Part
    When the user opens Body Properties for the body from the model browser
    And the user selects Black in Body Appearance
    And the user chooses OK
    Then the dialog closes
    And the solid is displayed with the Black appearance
    When the user reopens Body Properties for the same body
    Then Body Appearance displays Black
    When the user selects As Part in Body Appearance
    And the user chooses OK
    Then the dialog closes
    And the solid is displayed with the part appearance

  @needs_fixture
  Scenario: Dismiss body properties with Escape
    Given a part with a visible solid body is active in the MCAD Software
    And Body Properties is open for the body
    When the user presses Escape
    Then the dialog closes
    And the body row remains selected in the model browser
    And the solid remains highlighted in the viewport

  @needs_fixture
  Scenario: Discard a pending appearance with Escape
    Given a part with a visible solid body is active in the MCAD Software
    And the body appearance is set to As Part
    And Body Properties is open for the body
    When the user selects Black in Body Appearance
    And the user presses Escape
    Then the dialog closes
    When the user reopens Body Properties for the same body
    Then Body Appearance displays As Part
    When the user chooses Cancel
    Then the dialog closes

  @needs_fixture
  Scenario: Discard a pending appearance using the title-bar close control
    Given a part with a visible solid body is active in the MCAD Software
    And the body appearance is set to As Part
    And Body Properties is open for the body
    When the user selects Black in Body Appearance
    And the user closes the dialog using its title-bar close control
    Then the dialog closes
    When the user reopens Body Properties for the same body
    Then Body Appearance displays As Part
    When the user chooses Cancel
    Then the dialog closes
