@sketch @viewport @mouse
Feature: Interact with sketch entities in the viewport

  Background:
    Given the MCAD Software is displaying an editable sketch
    And the viewport pointer is idle

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Show hover feedback for a sketch curve offered to a selection tool
    Given the sketch contains a curve and a sketch tool is requesting a curve selection
    When the user hovers over a candidate curve segment
    Then the candidate segment receives pointer highlight feedback before it is selected

  @needs_fixture @capture_only @common_viewport_contract
  Scenario: Show and clear hover feedback on a sketch line
    Given the editable sketch contains one line and the pointer is away from it
    When the pointer rests over the line without drawing
    Then the line appears bright green
    When the pointer moves away from the line
    Then the line returns to its purple resting appearance

  @needs_fixture @capture_only @common_viewport_contract
  Scenario: Identify a sketch point under the pointer in Ready
    Given an editable sketch contains a visible line endpoint and the status is Ready
    When the pointer rests over the endpoint
    Then a nearby pick cue identifies 1 Point in Sketch1

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Select a sketch entity in the ready state
    Given an editable sketch contains an unselected line and the sketch is ready for input
    When the user clicks the line away from its endpoints and constraint glyphs
    Then the line becomes the selected sketch entity
    And the viewport displays a distinct selected state
    When the user clicks empty sketch space
    Then the line is no longer selected

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Resolve a pick where sketch entities overlap
    Given an editable sketch contains a curve and a selectable point at the same screen location
    When the user clicks the overlapping location
    Then the MCAD Software identifies the picked entity type
    And any available pick-choice control identifies the alternatives

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Create geometry through a pointer-driven sketch tool
    Given a sketch geometry tool is active and requesting viewport input
    When the user selects the positions required by that tool
    Then accepted geometry appears in the sketch
    And the tool advances to its next input or returns to Ready
    When the user presses Escape while a later placement preview is pending
    Then the pending preview is removed
    And previously accepted geometry remains in the sketch

  @needs_fixture @needs_capture @common_viewport_contract
  Scenario: Modify geometry with a tool that previews before commitment
    Given a sketch modification tool is requesting existing geometry
    And the tool has not committed its result
    When the user picks the required sketch entities
    Then the tool displays a pending preview of the modification
    When the user cancels before committing the result
    Then the pending preview is removed
    And the original sketch geometry remains unchanged
