@sketch @viewport @mouse @inherits_common_sketch_viewport
Feature: Hover over a sketch constraint glyph

  Background:
    Given the MCAD Software is displaying an editable sketch
    And the viewport pointer is idle

  @needs_fixture
  Scenario: Highlight geometry related to a parallel constraint glyph
    Given two lines have a visible parallel constraint glyph
    When the user hovers over the parallel constraint glyph
    Then both constrained lines highlight
    And the constraint remains in place
